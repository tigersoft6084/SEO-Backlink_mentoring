typeof window<"u"&&console.log("Chrome Extension Background Script Loaded");
