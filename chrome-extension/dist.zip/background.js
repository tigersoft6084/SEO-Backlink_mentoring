chrome.runtime.onInstalled.addListener(()=>{console.log("Surferlink Extension Installed")});
